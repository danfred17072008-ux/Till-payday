TILL PAYDAY — Android v0.2

A real Android project targeting API 36.

Included:
- Native Android launcher Activity
- Offline app UI
- Safe daily spend calculation
- Individual bills
- Quick-spend logging
- Can-I-afford-it checker
- Yorkshire Mode
- Local-only storage; no account or bank connection

Build:
Open this folder in Android Studio and build an APK for testing or an AAB for Google Play.
A release AAB must ultimately be signed with the owner's private upload key.

Package: com.tillpayday.app
Version: 0.2 (versionCode 2)
Target SDK: 36
